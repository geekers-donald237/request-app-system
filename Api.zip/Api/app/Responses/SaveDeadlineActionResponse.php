<?php

namespace App\Responses;

class SaveDeadlineActionResponse
{
    public string $message = '';
    public bool $isSaved = false;

}
