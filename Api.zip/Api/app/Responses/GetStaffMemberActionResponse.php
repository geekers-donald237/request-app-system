<?php

namespace App\Responses;

class GetStaffMemberActionResponse
{
    public mixed $staff = null;
}
