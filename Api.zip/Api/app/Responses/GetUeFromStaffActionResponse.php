<?php

namespace App\Responses;

class GetUeFromStaffActionResponse
{
    public string $message = '';
    public mixed $ues;

}
