<?php

namespace App\Responses;

class GetAllUserActionResponse
{
    public mixed $user = null;

}
