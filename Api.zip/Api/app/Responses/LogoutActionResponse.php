<?php

namespace App\Responses;

class LogoutActionResponse
{
    public string $message = '';
}
