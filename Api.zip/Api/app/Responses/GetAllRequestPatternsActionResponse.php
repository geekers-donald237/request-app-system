<?php

namespace App\Responses;

class GetAllRequestPatternsActionResponse
{
    public mixed $patterns = null;
}
