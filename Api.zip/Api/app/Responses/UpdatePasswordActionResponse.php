<?php

namespace App\Responses;

class UpdatePasswordActionResponse
{
    public string $message = '';
    public bool $isUpdated = false;

}
