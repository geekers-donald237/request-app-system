<?php

namespace App\Responses;

class NewsletterActionResponse
{
    public string $message = '';
}
