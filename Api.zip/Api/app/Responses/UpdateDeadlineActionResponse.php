<?php

namespace App\Responses;

class UpdateDeadlineActionResponse
{
    public string $message = '';
    public bool $isSaved = false;

}
