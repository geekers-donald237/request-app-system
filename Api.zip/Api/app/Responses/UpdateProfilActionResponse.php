<?php

namespace App\Responses;

class UpdateProfilActionResponse
{
    public  string $message = '';
}
