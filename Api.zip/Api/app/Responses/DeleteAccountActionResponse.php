<?php

namespace App\Responses;

class DeleteAccountActionResponse
{
    public  string $message = '';

}
