<?php

namespace App\Responses;


class GetUserRequestsActionResponse
{

    public mixed $requests;
    public string $message = '';
}
