<?php

namespace App\Responses;

class GetUeFromDepartmentWithDeadlineActionResponse
{
    public string $message = '';
    public mixed $ues;
}
