<?php

namespace App\Responses;

use App\Models\Request;

class GetRequestActionResponse
{
    public string $message = '';
    public mixed $request;
}
