<?php

namespace App\Responses;

class RegisterActionResponse
{
    public string $message = '';
    public bool $isRegistered = false;
}
