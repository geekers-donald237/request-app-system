<?php

namespace App\Responses;

class GetRequestHistoryActionResponse
{
    public string $message = '';
    public string $status = '';
    public mixed $history;
}
