<?php

namespace App\Responses;

class GetStudentDetailsResponse
{
    public string $status = '';
    public string $message = '';
    public array $data = [];
}
