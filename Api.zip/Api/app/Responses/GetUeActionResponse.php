<?php

namespace App\Responses;

class GetUeActionResponse
{
    public mixed $ue = null;

}
