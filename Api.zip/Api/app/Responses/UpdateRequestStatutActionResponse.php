<?php

namespace App\Responses;

class UpdateRequestStatutActionResponse
{
    public string $message = '';
}
