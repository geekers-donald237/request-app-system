<?php

namespace App\Responses;

class GetSecretaryRequestActionResponse
{
    public mixed $requests;
    public string $message = '';
}
