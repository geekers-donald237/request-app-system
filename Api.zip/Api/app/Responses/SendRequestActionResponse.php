<?php

namespace App\Responses;

class SendRequestActionResponse
{

    /**
     * @var true
     */
    public bool $isSent = false;
    public string $message = '';
}
