<?php

namespace App\Responses;

class GetUserProfileActionResponse
{
    public string $message = '';
    public mixed $user;
}
