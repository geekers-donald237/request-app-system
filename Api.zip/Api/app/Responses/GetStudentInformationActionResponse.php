<?php

namespace App\Responses;

class GetStudentInformationActionResponse
{
    public string $message = '';
    public array $data = [];

}
