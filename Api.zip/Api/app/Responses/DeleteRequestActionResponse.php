<?php

namespace App\Responses;

class DeleteRequestActionResponse
{

    /**
     * @var true
     */
    public bool $isDeleted = false;
    public string $message = '';
}
