<?php

namespace App\Responses;

class GetStaffRequestActionResponse
{
    public mixed $requests;
    public string $message = '';
}
