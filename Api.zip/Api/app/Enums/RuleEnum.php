<?php

namespace App\Enums;

enum RuleEnum: string
{
    case STUDENT = 'student';
    case SECRETARY = 'secretary';
    case STAFF = 'staff';
    case TECHNICAL_ADMIN = 'technical_admin';

}
