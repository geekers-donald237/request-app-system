
## Librairies utilisées

- **Laravel Breeze 2.6 :** Système d'authentification front-end préconçu pour Laravel.
- **... (ajoutez d'autres librairies utilisées le cas échéant)**
